#!/bin/bash

clear

cp -fv Defaults_orig.xml Defaults.xml
read -p "Restore ./Defaults.xml..."
