#!/bin/bash

clear

cp -fv Font_orig.xml Font.xml
read -p "Restore ./Font.xml..."
